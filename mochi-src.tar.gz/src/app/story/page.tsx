import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Our Story",
  description: "How Mochi started, what we believe, and where we're headed.",
};

const TIMELINE = [
  {
    date: "November 2024",
    title: "The Beginning",
    body: "Mochi World was founded with a single belief: Web3 education should be free, accessible, and honest. We started with a small group of traders sharing real knowledge — no hype, no paid gatekeeping.",
  },
  {
    date: "Early 2025",
    title: "Community Growth",
    body: "Word spread fast. Our no-nonsense approach to crypto education attracted thousands of learners — from total beginners to experienced traders looking for a disciplined community.",
  },
  {
    date: "Mid 2025",
    title: "Expanding the Ecosystem",
    body: "We launched curated airdrop guides, live trading sessions, and the BigBoss Calculator. 26,000+ members later, Mochi World is becoming the Web3 community for everyday people.",
  },
  {
    date: "Now",
    title: "Building the Future",
    body: "NFT collections, community merch, real-time market tools, and mentorship programs — we're building the most complete free Web3 ecosystem for our members.",
  },
];

export default function StoryPage() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <span className="section-eyebrow">01 &middot; Origin</span>
      <h1 className="section-title">Our Story</h1>
      <p className="section-sub">
        From a small chat group to a 26,000-strong Web3 community &mdash; here&apos;s how Mochi
        World came to be.
      </p>

      <div className="story-timeline mt-14">
        {TIMELINE.map((item) => (
          <div key={item.date} className="timeline-item">
            <div className="timeline-dot" />
            <div className="timeline-content">
              <div className="timeline-date">{item.date}</div>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
