import type { Metadata } from "next";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getCurrentUser } from "@/lib/auth";
import { Markdown } from "@/components/markdown";
import { MentorshipApplicationForm } from "@/components/mentorship-application-form";
import type { Cohort, CohortApplication, MentorshipSession } from "@/lib/types";

export const metadata: Metadata = {
  title: "Mentorship Application",
  description: "Apply for a Mochi mentorship wave.",
};

const STATUS_LABEL: Record<CohortApplication["status"], string> = {
  pending: "Pending review",
  accepted: "Accepted",
  rejected: "Not selected this wave",
  waitlisted: "Waitlisted",
};

export default async function MentorshipPage() {
  const supabase = await createClient();
  const user = await getCurrentUser();

  const { data: cohort } = await supabase
    .from("cohorts")
    .select("*")
    .in("status", ["upcoming", "active"])
    .order("starts_at", { ascending: true })
    .limit(1)
    .maybeSingle();

  const typedCohort = cohort as Cohort | null;

  let application: CohortApplication | null = null;
  let sessions: MentorshipSession[] = [];

  if (typedCohort && user) {
    const { data: app } = await supabase
      .from("cohort_applications")
      .select("*")
      .eq("cohort_id", typedCohort.id)
      .eq("user_id", user.id)
      .maybeSingle();
    application = app as CohortApplication | null;

    const { data: sessionsData } = await supabase
      .from("sessions")
      .select("*")
      .eq("cohort_id", typedCohort.id)
      .order("scheduled_at");
    sessions = (sessionsData ?? []) as MentorshipSession[];
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <span className="section-eyebrow">04 &middot; Mentorship</span>
      <h1 className="section-title">Mentorship Application</h1>
      <p className="section-sub">
        Small-group mentorship cohorts (&quot;Waves&quot;) covering risk management, chart
        reading, and trade review with a mentor.
      </p>

      {!typedCohort && (
        <p className="mt-10 text-sm text-muted">No mentorship wave is currently open for applications.</p>
      )}

      {typedCohort && (
        <div className="mt-10 mw-card p-6">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-xl font-bold">{typedCohort.name}</h2>
            <span className="chip chip-muted capitalize">{typedCohort.status}</span>
          </div>
          {typedCohort.description_md && (
            <div className="mt-3">
              <Markdown>{typedCohort.description_md}</Markdown>
            </div>
          )}
          {typedCohort.starts_at && (
            <p className="mt-2 text-xs text-muted">
              Starts {new Date(typedCohort.starts_at).toLocaleDateString()}
              {typedCohort.ends_at && ` — ends ${new Date(typedCohort.ends_at).toLocaleDateString()}`}
            </p>
          )}
        </div>
      )}

      {typedCohort && !user && (
        <p className="mt-6 rounded-xl border border-border bg-white/5 p-4 text-sm text-muted">
          Applications are currently closed.
        </p>
      )}

      {typedCohort && user && !application && (
        <div className="mt-6">
          <MentorshipApplicationForm cohortId={typedCohort.id} />
        </div>
      )}

      {typedCohort && user && application && (
        <div className="mt-6 mw-card p-6">
          <p className="text-sm font-medium">Application status: {STATUS_LABEL[application.status]}</p>
          <p className="mt-1 text-xs text-muted">
            Submitted {new Date(application.created_at).toLocaleDateString()}
          </p>
        </div>
      )}

      {sessions.length > 0 && (
        <div className="mt-10">
          <h2 className="mb-3 text-lg font-semibold">Upcoming sessions</h2>
          <div className="flex flex-col gap-2">
            {sessions.map((s) => (
              <div key={s.id} className="mw-card p-4">
                <p className="font-medium">{s.title}</p>
                <p className="text-xs text-muted">
                  {new Date(s.scheduled_at).toLocaleString("en-US", {
                    timeZone: "Asia/Manila",
                    dateStyle: "medium",
                    timeStyle: "short",
                  })}{" "}
                  (Manila time) &middot; {s.duration_minutes} min
                </p>
                {s.location_url && (
                  <a
                    href={s.location_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 inline-block text-xs text-foreground hover:underline"
                  >
                    Join link
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {user && (
        <p className="mt-10 text-xs text-muted">
          Have a mentor review a trade? Share it from your{" "}
          <Link href="/journal" className="text-foreground hover:underline">
            Trading Journal
          </Link>
          .
        </p>
      )}
    </div>
  );
}
