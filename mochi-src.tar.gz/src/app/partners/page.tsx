import type { Metadata } from "next";
import { PartnershipInquiryForm } from "@/components/partnership-inquiry-form";

export const metadata: Metadata = {
  title: "Partnership & Collaboration",
  description: "Partner with Mochi Web3 on airdrops, education, or community campaigns.",
};

export default function PartnersPage() {
  const calendlyUrl = process.env.NEXT_PUBLIC_CALENDLY_URL;

  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <span className="section-eyebrow">10 &middot; Partners</span>
      <h1 className="section-title">Partnership & Collaboration</h1>
      <p className="section-sub">
        We work with protocols, exchanges, and educators on curated airdrop listings,
        educational content, and community campaigns. We&apos;re selective &mdash; our
        community trusts our listings, and we protect that.
      </p>

      <ul className="mt-8 grid gap-3 sm:grid-cols-2">
        {[
          "Curated airdrop listings with a guide-backed writeup",
          "Co-hosted community events or AMAs",
          "Educational content collaborations",
          "Trading tools or resource cross-promotion",
        ].map((item) => (
          <li key={item} className="mw-card p-4 text-sm text-muted">
            {item}
          </li>
        ))}
      </ul>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div>
          <h2 className="text-xl font-bold">Book a call</h2>
          <p className="mt-2 text-sm text-muted">
            Prefer to talk it through first? Grab time on our calendar.
          </p>
          {calendlyUrl ? (
            <a href={calendlyUrl} target="_blank" rel="noopener noreferrer" className="btn-primary mt-4">
              Open Calendly
            </a>
          ) : (
            <p className="mt-4 text-sm text-muted">
              Calendly link coming soon &mdash; use the inquiry form for now.
            </p>
          )}
        </div>

        <div>
          <h2 className="text-xl font-bold">Send an inquiry</h2>
          <p className="mt-2 text-sm text-muted">We typically respond within a few days.</p>
          <div className="mt-4">
            <PartnershipInquiryForm />
          </div>
        </div>
      </div>
    </div>
  );
}
