import Image from "next/image";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { AboutSection } from "@/components/landing/about-section";
import { OfferSlider } from "@/components/landing/offer-slider";
import { Reveal } from "@/components/landing/reveal";
import { ScrollProgress } from "@/components/landing/scroll-progress";
import { Testimonials } from "@/components/sections/Testimonials";
import { LANDING_SECTIONS, SOFT_LAUNCH } from "@/lib/site-visibility";
import type { TeamMember } from "@/lib/types";

const DISCORD_URL = process.env.NEXT_PUBLIC_DISCORD_URL || "https://discord.gg/ZGJm8vKUbz";
const MERCH_URL = process.env.NEXT_PUBLIC_MERCH_URL || "#";

const HERO_STATS = [
  { num: "26K+", label: "Members" },
  { num: "100%", label: "Free Education" },
  { num: "3+", label: "Years Active" },
];

const OPPORTUNITIES = [
  {
    icon: "🪂",
    title: "Airdrop Hunting",
    body: "Vetted, step-by-step guides to earn from high-potential crypto airdrops — no scams, no noise, just real opportunities with free guides.",
    href: "/airdrops",
  },
  {
    icon: "💼",
    title: "Job Opportunities",
    body: "Looking to contribute to the Mochi Web3 ecosystem? We're always searching for passionate community mods, researchers, and creators.",
    href: "/jobs",
  },
  {
    icon: "📡",
    title: "Community Alpha",
    body: "Get early project calls, market signals, and exclusive insights shared daily by our mentors and analysts inside the Discord.",
    href: "/community",
  },
];

const MERCH = [
  {
    emoji: "👕",
    title: "Mochi Hoodie",
    body: "Premium heavyweight hoodie with embroidered Mochi logo. Limited first drop.",
  },
  {
    emoji: "🧢",
    title: "Mochi Cap",
    body: "Structured snapback with Mochi emblem. Multiple colorways available.",
  },
  {
    emoji: "👕",
    title: "Trader Tee",
    body: "Graphic tee with Mochi trading motifs. 100% cotton, oversized fit.",
  },
];

const NFTS = [
  {
    emoji: "🍡",
    title: "Mochi Genesis",
    body: "The original collection. 1,000 unique Mochi characters granting lifetime Discord access and priority mentorship.",
    meta: "Supply: 1,000",
    status: { label: "Upcoming", className: "status-new" },
    gradient: "linear-gradient(135deg,var(--accent3),var(--teal))",
  },
  {
    emoji: "🏯",
    title: "Mochi City Passes",
    body: "Access pass for Mochi Crypto City — the virtual trading hub. Holders get early feature access and exclusive tools.",
    meta: "Supply: 5,000",
    status: { label: "Upcoming", className: "status-new" },
    gradient: "linear-gradient(135deg,var(--teal),var(--accent))",
  },
  {
    emoji: "📈",
    title: "Trader Badges",
    body: "Soul-bound achievement NFTs awarded to members who complete education milestones. Non-transferable proof of knowledge.",
    meta: "Soulbound",
    status: { label: "● Active", className: "status-live" },
    gradient: "linear-gradient(135deg,#f472b6,var(--accent3))",
  },
];

// PLACEHOLDER: the reference ships six numbered slots with no names attached.
// Fill `ign` in as the IGNs come through; the chip renders an em dash until then.
const FUNDED_TRADERS: { ign: string | null }[] = [
  { ign: null },
  { ign: null },
  { ign: null },
  { ign: null },
  { ign: null },
  { ign: null },
];

const FUNDED_TOTAL_PESO = "35,000,000";

// PLACEHOLDER: `src` stands in for the reference's empty <image-slot>. Point it
// at a real photo in /public/images to fill the card.
const EVENTS: { title: string; meta: string; src: string | null; alt: string }[] = [
  { title: "Davao Summer Event", meta: "Davao City", src: null, alt: "Davao event photo" },
  { title: "Community Meetup", meta: "In person", src: null, alt: "Meetup photo" },
  { title: "Add your event", meta: "Send name, date, city", src: null, alt: "Event photo" },
];


export default async function HomePage() {
  const supabase = await createClient();
  // Full roster — the About overlay renders the whole tiered org chart.
  const { data } = await supabase
    .from("team_members")
    .select("*")
    .eq("is_active", true)
    .order("position");

  const team = (data ?? []) as TeamMember[];

  return (
    <div className="mw-landing">
      <ScrollProgress />

      {/* ══════════════ HERO ══════════════ */}
      <section className="hero" id="home">
        <div className="hero-dots" />
        <div className="hero-glow-bg" />
        <div className="hero-mesh" />
        <div className="hero-inner">
          <div className="hero-inner-grid">
            <div className="hero-left">
              <div className="hero-badge">
                <span className="badge-dot" />
                <span>Web3 Education — Free, Forever</span>
              </div>
              <h1>
                Master Web3.
                <br />
                <em className="ht-serif">Explore Crypto.</em>
                <br />
                Build your Future.
              </h1>
              <p className="hero-sub">
                Mochi Web3 breaks down blockchain so you can trade smarter, grab airdrops, and grow
                your wealth — no paywalls, no gatekeeping, no hidden fees.
              </p>
              {/* Soft launch gates /learn and /airdrops, so the hero points at
                  what is actually live rather than at a redirect. */}
              <div className="hero-actions">
                {SOFT_LAUNCH ? (
                  <>
                    <a
                      href={DISCORD_URL}
                      className="btn-dark"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <span>Join Our Discord</span>
                      <span className="btn-icon">↗</span>
                    </a>
                    <Link href="/story" className="btn-outline">
                      <span>Our Story</span>
                    </Link>
                  </>
                ) : (
                  <>
                    <Link href="/learn" className="btn-dark">
                      <span>Start Learning</span>
                      <span className="btn-icon">↗</span>
                    </Link>
                    <Link href="/airdrops" className="btn-outline">
                      <span>Explore Airdrops</span>
                    </Link>
                  </>
                )}
              </div>
              <div className="hero-stats">
                {HERO_STATS.map((s) => (
                  <div className="hero-stat" key={s.label}>
                    <span className="num">{s.num}</span>
                    <span className="label">{s.label}</span>
                  </div>
                ))}
              </div>
              <div className="scroll-indicator">
                <div className="scroll-mouse">
                  <div className="scroll-dot" />
                </div>
                <span>Scroll</span>
              </div>
            </div>

            <div className="orb-stage">
              <div className="orb-ring" />
              <div className="orb-ring r2" />
              <div className="hexglow">
                <Image src="/images/mw-logo.png" alt="Mochi Web3 crest" width={300} height={300} priority />
              </div>
              <div className="orb-chip c1">
                <span className="ic" style={{ background: "rgba(94,224,160,.16)" }}>
                  🎯
                </span>
                <div>
                  <span>Quest complete</span>
                  <small>+250 pts</small>
                </div>
              </div>
              <div className="orb-chip c2">
                <span className="ic" style={{ background: "rgba(78,155,255,.16)" }}>
                  🪂
                </span>
                <div>
                  <span>New airdrop</span>
                  <small>ZkVault live</small>
                </div>
              </div>
              <div className="orb-chip c3">
                <span className="ic" style={{ background: "rgba(166,107,240,.18)" }}>
                  ✅
                </span>
                <div>
                  <span>Guide verified</span>
                  <small>by Mochi team</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════ OUR STORY (+ about overlay) ══════════════ */}
      <AboutSection team={team} />

      {/* ══════════════ WHAT WE OFFER SLIDER ══════════════ */}
      <OfferSlider />

      {/* ══════════════ OPPORTUNITIES ══════════════ */}
      {LANDING_SECTIONS.opportunities && (
      <section id="airdrops" className="v2-light">
        <div className="container">
          <Reveal className="opp-header">
            <div className="opp-header-left">
              <div className="section-eyebrow">
                <span className="badge-dot" /> Opportunities
              </div>
              <h2 className="opp-title">
                The right Web3 opportunity
                <br />
                <em className="ht-serif">for your journey.</em>
              </h2>
            </div>
            <div className="opp-header-right">
              <p>
                From airdrop hunting to community careers and exclusive alpha — find the opportunity
                that fits where you are in your Web3 journey.
              </p>
            </div>
          </Reveal>

          <Reveal className="opp-cards">
            {OPPORTUNITIES.map((o) => (
              <Link href={o.href} className="opp-card" key={o.title}>
                <div className="opp-card-icon">{o.icon}</div>
                <h3>{o.title}</h3>
                <p>{o.body}</p>
              </Link>
            ))}
          </Reveal>
        </div>
      </section>
      )}

      {/* ══════════════ COMMUNITY MERCH ══════════════ */}
      {LANDING_SECTIONS.merch && (
      <section id="merch" className="v2-dark">
        <div className="container">
          <Reveal className="v2-section-head">
            <div className="section-eyebrow">
              <span className="badge-dot" />
              Merch
            </div>
            <h2 className="section-title">
              Community <em className="ht-serif">Merch</em>
            </h2>
            <p className="section-sub">
              Represent the Mochi community. Limited drops, exclusive designs, built for the
              culture.
            </p>
          </Reveal>

          <Reveal className="merch-grid">
            {MERCH.map((m) => (
              <div className="merch-card" key={m.title}>
                {/* PLACEHOLDER: emoji stands in for real product photography */}
                <div className="merch-img">{m.emoji}</div>
                <div className="merch-info">
                  <h3>{m.title}</h3>
                  <p>{m.body}</p>
                  <div className="merch-status">
                    <span className="status-chip status-new">Coming Soon</span>
                  </div>
                </div>
              </div>
            ))}
          </Reveal>

          <div style={{ marginTop: "2rem", textAlign: "center" }}>
            <a href={MERCH_URL} className="btn-outline" target="_blank" rel="noopener noreferrer">
              <span>Visit the Shop</span>
            </a>
          </div>
        </div>
      </section>
      )}

      {/* ══════════════ NFT COLLECTIONS ══════════════ */}
      {LANDING_SECTIONS.nft && (
      <section id="nft" className="v2-light">
        <div className="container">
          <Reveal className="v2-section-head">
            <div className="section-eyebrow">
              <span className="badge-dot" />
              NFTs
            </div>
            <h2 className="section-title">
              NFT Community <em className="ht-serif">Collections</em>
            </h2>
            <p className="section-sub">
              Community-owned NFT collections that unlock exclusive Mochi World perks, access, and
              identity on-chain.
            </p>
          </Reveal>

          <Reveal className="nft-grid">
            {NFTS.map((n) => (
              <div className="nft-card" key={n.title}>
                {/* PLACEHOLDER: gradient + emoji stand in for real collection artwork */}
                <div className="nft-img" style={{ background: n.gradient }}>
                  <span className="nft-emoji">{n.emoji}</span>
                </div>
                <div className="nft-info">
                  <h3>{n.title}</h3>
                  <p>{n.body}</p>
                  <div className="nft-meta">
                    <span>{n.meta}</span>
                    <span className={`status-chip ${n.status.className}`}>{n.status.label}</span>
                  </div>
                </div>
              </div>
            ))}
          </Reveal>

          <div style={{ marginTop: "2rem", textAlign: "center" }}>
            <Link href="/nft" className="btn-dark">
              <span>Explore Collections</span>
              <span className="btn-icon">↗</span>
            </Link>
          </div>
        </div>
      </section>
      )}

      {/* ══════════════ COMMUNITY LOVE ══════════════ */}
      {/* The marquee of invented quotes was replaced by the real survey
          responses in src/data/testimonials.ts. The `community-love` id is kept
          so existing anchors still resolve. */}
      {LANDING_SECTIONS.testimonials && <Testimonials />}

      {/* ══════════════ FUNDED TRADERS ══════════════ */}
      {LANDING_SECTIONS.funded && (
      <section id="funded" className="v2-light">
        <div className="container">
          <Reveal className="v2-section-head">
            <div className="section-eyebrow">
              <span className="badge-dot" />
              Community Wins
            </div>
            <h2 className="section-title">
              Funded <em className="ht-serif">Traders</em>
            </h2>
            <p className="section-sub">
              Members who passed their evaluations and now trade funded capital — after learning the
              process here, for free.
            </p>
          </Reveal>

          <Reveal className="fund-lede">
            <div>
              <div className="fund-figure-label">Community wins in peso value</div>
              <p className="fund-figure">{FUNDED_TOTAL_PESO}</p>
            </div>
            <p className="fund-note">
              Every peso earned by members who learned risk management inside Mochi Web3.
            </p>
          </Reveal>

          <Reveal className="fund-subhead">
            <span>Funded members</span>
            <span className="fund-subrule" />
            <span>By IGN</span>
          </Reveal>

          <Reveal className="fund-list">
            {FUNDED_TRADERS.map((t, i) => (
              <div className="fund-chip" key={i}>
                <span className="fund-num">{String(i + 1).padStart(2, "0")}</span>
                <span className="fund-ign">{t.ign ?? "—"}</span>
              </div>
            ))}
          </Reveal>

          {FUNDED_TRADERS.every((t) => !t.ign) && (
            <Reveal className="fund-empty">
              Member names are being confirmed — this roster goes up as each trader signs off.
            </Reveal>
          )}
        </div>
      </section>
      )}

      {/* ══════════════ EVENTS ══════════════ */}
      {LANDING_SECTIONS.events && (
      <section id="events" className="ev-blue">
        <div className="container">
          <Reveal className="v2-section-head">
            <div className="section-eyebrow">
              <span className="badge-dot" />
              On the ground
            </div>
            <h2 className="section-title">
              Community <em className="ht-serif">Events</em>
            </h2>
            <p className="section-sub">
              Meetups, summits, and study sessions — online and in person, across the Philippines.
            </p>
          </Reveal>

          <Reveal className="ev-grid">
            {EVENTS.map((e) => (
              <div className="ev-card" key={e.title}>
                <div className="ev-shot">
                  {e.src ? (
                    <Image src={e.src} alt={e.alt} width={420} height={240} />
                  ) : (
                    <div className="ev-shot-empty">{e.alt}</div>
                  )}
                </div>
                <div className="ev-title">{e.title}</div>
                <div className="ev-meta">{e.meta}</div>
              </div>
            ))}
          </Reveal>
        </div>
      </section>
      )}

      {/* ══════════════ PARTNERSHIP ══════════════ */}
      <section id="partnership" className="v2-light">
        <div className="container">
          <Reveal className="v2-section-head">
            <div className="section-eyebrow">
              <span className="badge-dot" />
              Partners
            </div>
            <h2 className="section-title">
              Partnership &amp; <em className="ht-serif">Collaboration</em>
            </h2>
            <p className="section-sub">
              We collaborate with Web3 projects, brands, and institutions that share our mission of
              accessible education.
            </p>
          </Reveal>

          <Reveal className="partner-grid">
            <div className="partner-card">
              <div className="edu-icon">🏗️</div>
              <h3>Web3 Projects</h3>
              <p>
                Collaborate on airdrop campaigns, community activations, and protocol education.
                Reach thousands of engaged Web3 learners.
              </p>
              <Link href="/partners" className="card-link">
                Partner With Us →
              </Link>
            </div>

            <div className="partner-card highlight">
              <div className="edu-icon">🤝</div>
              <h3>Strategic Partners</h3>
              <p>
                Long-term ecosystem collaborations. Let&apos;s build something that benefits both
                communities. Get in touch directly.
              </p>
              {/* PLACEHOLDER: swap for your real booking link */}
              <a
                href="https://calendly.com/gab-fornier"
                className="btn-dark"
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: "inline-flex", marginTop: "1.5rem" }}
              >
                <span>Book a Call</span>
                <span className="btn-icon">↗</span>
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ══════════════ FINAL CTA ══════════════ */}
      <section id="join" className="v2-dark">
        <div className="container">
          <Reveal className="v2-section-head">
            <div className="section-eyebrow">
              <span className="badge-dot" />
              Get Involved
            </div>
            <h2 className="section-title">
              Join us. <em className="ht-serif">Build with us.</em>
            </h2>
            <p className="section-sub">
              Free forever, community-run, and open to anyone willing to learn.
            </p>
          </Reveal>
          <div style={{ marginTop: "2rem", textAlign: "center" }}>
            <a href={DISCORD_URL} className="btn-dark" target="_blank" rel="noopener noreferrer">
              <span>Join Our Discord</span>
              <span className="btn-icon">↗</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
