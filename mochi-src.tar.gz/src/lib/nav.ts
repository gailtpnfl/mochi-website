import { isRouteVisible } from "./site-visibility";

export interface NavLink {
  label: string;
  href?: string;
  phase: 1 | 2 | 3 | 4;
  external?: boolean;
  children?: { label: string; href: string; phase: 1 | 2 | 3 | 4 }[];
}

export const NAV_LINKS: NavLink[] = [
  // Our Story and Core Team sit at the top level rather than under an "About"
  // dropdown. /community is reachable from the footer.
  { label: "Our Story", href: "/story", phase: 1 },
  { label: "Core Team", href: "/core-team", phase: 1 },
  {
    label: "Learn",
    phase: 2,
    children: [
      { label: "Learn Web3", href: "/learn", phase: 2 },
      { label: "Crypto Trading 101", href: "/learn/crypto-trading-101", phase: 2 },
      { label: "Mentorship", href: "/mentorship", phase: 3 },
      { label: "Trading Journal", href: "/journal", phase: 3 },
      { label: "TradingView", href: "/tradingview", phase: 2 },
    ],
  },
  {
    label: "Opportunities",
    phase: 1,
    children: [
      { label: "Airdrop Hunting", href: "/airdrops", phase: 1 },
      { label: "Job Opportunities", href: "/jobs", phase: 3 },
    ],
  },
  {
    label: "Trading Materials",
    href: "/tools",
    phase: 2,
    children: [
      { label: "BigBoss Calculator", href: "/tools/bigboss-calculator", phase: 2 },
      { label: "Watchlist by BigDaddyDaks", href: "/tools/watchlist", phase: 2 },
      { label: "FVG Trading Indicator", href: "/tools/fvg-indicator", phase: 2 },
      { label: "Mochi Crypto City", href: "/tools/crypto-city", phase: 2 },
    ],
  },
  {
    label: "Collections",
    phase: 4,
    children: [{ label: "NFT Collections", href: "/nft", phase: 4 }],
  },
  { label: "Partnership", href: "/partners", phase: 1 },
];

export const MERCH_LINK = {
  label: "Merch",
  href: process.env.NEXT_PUBLIC_MERCH_URL || "#",
  phase: 4 as const,
};

/**
 * `NAV_LINKS` with soft-launch-hidden destinations removed — a group whose
 * children are all hidden drops out entirely rather than rendering an empty
 * dropdown. Render from this, not `NAV_LINKS`.
 */
export const VISIBLE_NAV_LINKS: NavLink[] = NAV_LINKS.reduce<NavLink[]>((acc, link) => {
  const children = link.children?.filter((child) => isRouteVisible(child.href));
  const selfVisible = link.href ? isRouteVisible(link.href) : false;

  if (children?.length) {
    acc.push({ ...link, href: selfVisible ? link.href : undefined, children });
  } else if (selfVisible) {
    acc.push({ ...link, children: undefined });
  }

  return acc;
}, []);
