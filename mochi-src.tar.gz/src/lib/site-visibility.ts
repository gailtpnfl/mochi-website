/**
 * Soft-launch gate.
 *
 * While `SOFT_LAUNCH` is true the public site is limited to the landing page,
 * Our Story, Core Team, and Partnership. Everything else is delinked from the
 * nav/footer, redirected to `/` by `proxy.ts`, and dropped from `sitemap.xml`.
 *
 * To restore the full site: set `SOFT_LAUNCH` to false. That is the only edit
 * needed — every consumer derives its behaviour from this flag.
 */
export const SOFT_LAUNCH = true;

/** Pages the public can reach during soft launch. Matched exactly. */
export const PUBLIC_ROUTES = ["/", "/story", "/core-team", "/team", "/partners"] as const;

/**
 * Reachable regardless of soft launch, matched as prefixes.
 *
 * Legal pages stay up because the footer links them; `/admin`, `/api` and the
 * metadata routes have to keep working for the app to function at all
 * (`/sitemap.xml` is matched by the proxy matcher, so omitting it here would
 * redirect search engines to the landing page).
 *
 * There is no `/login` or `/auth` entry: sign-in was removed from the project,
 * so those routes no longer exist.
 */
const ALWAYS_ALLOWED_PREFIXES = [
  "/terms",
  "/privacy",
  "/admin",
  "/api",
  "/sitemap.xml",
  "/robots.txt",
];

/** True when `pathname` should be served. Safe on both server and client. */
export function isRouteVisible(pathname: string): boolean {
  if (!SOFT_LAUNCH) return true;

  // Normalise "" (used by the sitemap for home) and any trailing slash.
  const path = pathname === "" ? "/" : pathname.replace(/(.)\/+$/, "$1");

  if ((PUBLIC_ROUTES as readonly string[]).includes(path)) return true;

  return ALWAYS_ALLOWED_PREFIXES.some((p) => path === p || path.startsWith(`${p}/`));
}

/**
 * Landing-page sections. The hidden ones all advertise pages that soft launch
 * takes down, so leaving them up would point visitors at redirects.
 *
 * Testimonials stay up: the section is self-contained quotes with no links out,
 * so nothing in it depends on a gated page.
 *
 * Funded and events are the same shape as testimonials — self-contained, no
 * links out — but both still carry placeholder content (the IGN chips read "—",
 * the event photos are empty slots). Flip either to `false` to pull it until the
 * real content lands.
 */
export const LANDING_SECTIONS = {
  story: true,
  whatWeOffer: true,
  opportunities: !SOFT_LAUNCH,
  merch: !SOFT_LAUNCH,
  nft: !SOFT_LAUNCH,
  testimonials: true,
  funded: true,
  events: true,
  partnership: true,
  join: true,
} as const;

/**
 * The Merch nav/footer entry points at an external store. It is hidden with the
 * on-page Merch section rather than with the route gate, since it is not a
 * route this app serves.
 */
export const SHOW_MERCH_LINK = !SOFT_LAUNCH;
