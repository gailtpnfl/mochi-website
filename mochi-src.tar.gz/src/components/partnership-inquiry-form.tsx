"use client";

import { useState, type FormEvent } from "react";

export function PartnershipInquiryForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setErrorMessage("");

    const form = event.currentTarget;
    const formData = new FormData(form);
    const payload = {
      org_name: formData.get("org_name"),
      contact_name: formData.get("contact_name"),
      email: formData.get("email"),
      message: formData.get("message"),
    };

    try {
      const res = await fetch("/api/partnership-inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error ?? "Something went wrong.");
      }

      setStatus("success");
      form.reset();
    } catch (err) {
      setStatus("error");
      setErrorMessage(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  if (status === "success") {
    return (
      <div className="mw-card p-6 text-sm text-muted">
        Thanks &mdash; we&apos;ve received your inquiry and will follow up by email.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mw-card flex flex-col gap-4 p-6">
      <div>
        <label htmlFor="org_name" className="mb-1 block text-sm font-medium">
          Organization *
        </label>
        <input
          id="org_name"
          name="org_name"
          required
          className="w-full rounded-lg border border-border bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--accent-end)]"
        />
      </div>
      <div>
        <label htmlFor="contact_name" className="mb-1 block text-sm font-medium">
          Your name
        </label>
        <input
          id="contact_name"
          name="contact_name"
          className="w-full rounded-lg border border-border bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--accent-end)]"
        />
      </div>
      <div>
        <label htmlFor="email" className="mb-1 block text-sm font-medium">
          Email *
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          className="w-full rounded-lg border border-border bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--accent-end)]"
        />
      </div>
      <div>
        <label htmlFor="message" className="mb-1 block text-sm font-medium">
          What are you looking to do?
        </label>
        <textarea
          id="message"
          name="message"
          rows={4}
          className="w-full rounded-lg border border-border bg-white/5 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--accent-end)]"
        />
      </div>
      {status === "error" && <p className="text-xs text-red-400">{errorMessage}</p>}
      <button
        type="submit"
        disabled={status === "loading"}
        className="rounded-full bg-gradient-to-r from-[var(--accent-start)] to-[var(--accent-end)] px-6 py-2.5 text-sm font-medium text-white transition hover:opacity-90 disabled:opacity-60"
      >
        {status === "loading" ? "Sending..." : "Send inquiry"}
      </button>
    </form>
  );
}
