"use client";

import { useActionState } from "react";
import { applyToCohort } from "@/app/mentorship/actions";

type ActionState = { error?: string; ok?: boolean } | undefined;

export function MentorshipApplicationForm({ cohortId }: { cohortId: string }) {
  const boundAction = applyToCohort.bind(null, cohortId);
  const [state, action, pending] = useActionState<ActionState, FormData>(boundAction, undefined);

  if (state?.ok) {
    return (
      <div className="mw-card p-6 text-sm text-muted">
        Application submitted &mdash; we&apos;ll follow up once it&apos;s reviewed.
      </div>
    );
  }

  return (
    <form action={action} className="mw-card flex flex-col gap-4 p-6">
      <div>
        <label htmlFor="experience_level" className="mb-1 block text-sm font-medium">
          Experience level
        </label>
        <select id="experience_level" name="experience_level" className="input" defaultValue="beginner">
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
      </div>
      <div>
        <label htmlFor="motivation_md" className="mb-1 block text-sm font-medium">
          Why do you want to join this wave?
        </label>
        <textarea id="motivation_md" name="motivation_md" required rows={5} className="input" />
      </div>
      {state?.error && <p className="text-xs text-red-400">{state.error}</p>}
      <button
        type="submit"
        disabled={pending}
        className="self-start rounded-full bg-gradient-to-r from-[var(--accent-start)] to-[var(--accent-end)] px-6 py-2.5 text-sm font-medium text-white transition hover:opacity-90 disabled:opacity-60"
      >
        {pending ? "Submitting..." : "Apply"}
      </button>
    </form>
  );
}
