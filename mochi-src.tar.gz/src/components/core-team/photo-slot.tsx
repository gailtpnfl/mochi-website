import Image from "next/image";
import { initials } from "@/data/coreTeam";

/**
 * Replaces the redesign's `<image-slot>` scaffold, which is a design-tool
 * custom element and must not ship.
 *
 * Every slot in the source file is empty, so the fallback is the state you
 * actually see today: a tinted panel with the member's initials, sized exactly
 * like the photo it stands in for, so nothing reflows when real photography
 * lands. Set `photo` on the member to swap it in.
 *
 * Sizes live in core-team.css keyed by variant; the numbers here are only the
 * intrinsic dimensions next/image needs to reserve the right aspect ratio.
 */
const VARIANTS = {
  /** ct-founder — 340×420 rounded */
  founder: { w: 340, h: 420 },
  /** ct-coo / ct-cto / ct-cmo / ct-cco / ct-director — 96px circles */
  lead: { w: 96, h: 96 },
  /** ct-m3 / ct-m6 — mentor portraits, 300px tall, fluid width */
  mentor: { w: 380, h: 300 },
  /** ct-mod1…ct-mod6 — 120px circles */
  moderator: { w: 120, h: 120 },
} as const;

export type PhotoSlotVariant = keyof typeof VARIANTS;

export function PhotoSlot({
  name,
  photo,
  variant,
  priority = false,
}: {
  name: string;
  photo?: string;
  variant: PhotoSlotVariant;
  priority?: boolean;
}) {
  const { w, h } = VARIANTS[variant];
  const className = `ct-slot ct-slot-${variant}`;

  if (photo) {
    return (
      <div className={className}>
        <Image src={photo} alt={name} width={w} height={h} priority={priority} />
      </div>
    );
  }

  return (
    <div className={className} role="img" aria-label={name}>
      <span className="ct-slot-initials" aria-hidden>
        {initials(name)}
      </span>
    </div>
  );
}
