import Link from "next/link";
import Image from "next/image";
import { NewsletterForm } from "@/components/newsletter-form";
import { isRouteVisible, SHOW_MERCH_LINK } from "@/lib/site-visibility";

const DISCORD_URL = process.env.NEXT_PUBLIC_DISCORD_URL || "https://discord.gg/ZGJm8vKUbz";

const SOCIALS = [
  { label: "X", icon: "𝕏", href: "https://twitter.com/mochiworld" },
  { label: "Discord", icon: "💬", href: DISCORD_URL },
  { label: "Telegram", icon: "✈️", href: "https://t.me/mochiworld" },
  { label: "Facebook", icon: "📘", href: "https://facebook.com/mochiworld" },
];

interface FooterLink {
  label: string;
  href: string;
  external?: boolean;
  /** External store link — gated with the on-page Merch section, not by route. */
  merch?: boolean;
}

const FOOTER_COLUMNS: { heading: string; links: FooterLink[] }[] = [
  {
    heading: "Learn",
    links: [
      { label: "Learn Web3", href: "/learn" },
      { label: "Airdrop Guides", href: "/airdrops" },
      { label: "Mentorship", href: "/mentorship" },
      { label: "Trading Journal", href: "/journal" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "Our Story", href: "/story" },
      { label: "Core Team", href: "/team" },
      { label: "Job Opportunities", href: "/jobs" },
      { label: "Partner With Us", href: "/partners" },
    ],
  },
  {
    heading: "Community",
    links: [
      { label: "Discord", href: DISCORD_URL, external: true },
      { label: "Community", href: "/community" },
      { label: "NFT Collections", href: "/nft" },
      {
        label: "Community Merch",
        href: process.env.NEXT_PUBLIC_MERCH_URL || "#",
        external: true,
        merch: true,
      },
    ],
  },
  {
    heading: "Tools",
    links: [
      { label: "BigBoss Calculator", href: "/tools/bigboss-calculator" },
      { label: "FVG Indicator", href: "/tools/fvg-indicator" },
      { label: "Watchlist", href: "/tools/watchlist" },
      { label: "TradingView", href: "/tradingview" },
    ],
  },
];

/** External links always survive; internal ones go through the soft-launch gate. */
function linkVisible(link: FooterLink): boolean {
  if (link.merch) return SHOW_MERCH_LINK;
  if (link.external) return true;
  return isRouteVisible(link.href);
}

// A column whose links are all hidden is dropped rather than left as a bare heading.
const VISIBLE_COLUMNS = FOOTER_COLUMNS.map((col) => ({
  ...col,
  links: col.links.filter(linkVisible),
})).filter((col) => col.links.length > 0);

const LEGAL_LINKS = [
  { label: "Terms", href: "/terms" },
  { label: "Privacy", href: "/privacy" },
  { label: "Community", href: "/community" },
].filter((l) => isRouteVisible(l.href));

export function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="footer-inner">
          <div className="footer-brand">
            <Link href="/" className="nav-logo">
              <Image src="/images/mw-logo.png" alt="Mochi Web3" width={40} height={40} />
              <span className="brand-word">Mochi Web3</span>
            </Link>
            <p>
              Free Web3 education for everyone. Spot &amp; futures trading, airdrop hunting, and
              navigating the ecosystem — built by the community, for the community.
            </p>
            <div className="footer-socials">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  className="ft-soc"
                  target="_blank"
                  rel="noopener noreferrer"
                  title={s.label}
                >
                  <span>{s.icon}</span>
                </a>
              ))}
            </div>
            <div className="footer-newsletter">
              <p className="footer-newsletter-label">Stay in the loop</p>
              <NewsletterForm />
            </div>
          </div>

          {VISIBLE_COLUMNS.map((col) => (
            <div key={col.heading} className="footer-col">
              <h4>{col.heading}</h4>
              <ul>
                {col.links.map((link) => (
                  <li key={link.label}>
                    {link.external ? (
                      <a href={link.href} target="_blank" rel="noopener noreferrer">
                        {link.label}
                      </a>
                    ) : (
                      <Link href={link.href}>{link.label}</Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="footer-disclaimer">
          Mochi Web3 is for education and community purposes only. Nothing on this site —
          including airdrop guides, watchlists, indicators, or trading tools — constitutes
          financial, investment, or trading advice. Web3 and crypto assets carry risk, including
          total loss. Always do your own research.
        </p>

        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} Mochi Web3. All rights reserved.</p>
          <div className="footer-legal">
            {LEGAL_LINKS.map((l) => (
              <Link key={l.href} href={l.href}>
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
      <div className="footer-watermark">Mochi Web3</div>
    </footer>
  );
}
