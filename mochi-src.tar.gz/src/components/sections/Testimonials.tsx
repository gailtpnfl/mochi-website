import { Reveal } from "@/components/landing/reveal";
import { HeroQuote } from "@/components/testimonials/HeroQuote";
import { InPersonQuote } from "@/components/testimonials/InPersonQuote";
import { MiniQuote } from "@/components/testimonials/MiniQuote";
import { QuoteCard } from "@/components/testimonials/QuoteCard";
import {
  byTier,
  communityStats,
  communityWinsPeso,
  miniCount,
  pad2,
} from "@/data/testimonials";
import "./testimonials.css";

/**
 * Community testimonials, matching design-reference/sections/community-love.html:
 * stat row, the wide peso-value card, an editorial lede quote, four numbered
 * rows, a scrolling ticker, and the in-person strip.
 *
 * Everything renders from src/data/testimonials.ts, which drops any record
 * without confirmed consent before it reaches here.
 */
export function Testimonials() {
  const hero = byTier("hero")[0];
  const rows = byTier("card");
  const ticks = byTier("mini");
  const inperson = byTier("inperson")[0];

  return (
    <section id="community-love" className="v2-dark">
      <div className="container">
        <Reveal className="v2-section-head">
          <div className="section-eyebrow">
            <span className="badge-dot" />
            Community Testimonials
          </div>
          <h2 className="section-title">
            What Our <em className="ht-serif">Members Say</em>
          </h2>
          <p className="section-sub">
            26,000+ members and counting. Real words from members, shared with their consent — no
            paid signals, no gatekeeping.
          </p>
        </Reveal>

        <Reveal className="ml-stats">
          {communityStats.map((s) => (
            <div className="ml-stat" key={s.label}>
              <div className="ml-stat-label">{s.label}</div>
              <div className="ml-stat-value">{s.value}</div>
            </div>
          ))}
        </Reveal>

        <Reveal className="ml-stat-wide">
          <div className="ml-stat-label">Community wins in peso value</div>
          <div className="ml-stat-big">{communityWinsPeso}</div>
        </Reveal>

        {/* Required adjacent to the peso figure, not only in the footer. */}
        <p className="ml-disclaimer">
          Not financial advice — educational content only. Figures are community-reported and past
          results do not indicate future outcomes.
        </p>

        {hero && (
          <Reveal>
            <HeroQuote member={hero} />
          </Reveal>
        )}

        {rows.length > 0 && (
          <Reveal className="ml-rows">
            {rows.map((m, i) => (
              <QuoteCard member={m} index={i} key={m.id} />
            ))}
          </Reveal>
        )}

        {ticks.length > 0 && (
          <>
            <Reveal className="ml-subhead">
              <span>More from the community</span>
              <span className="ml-rule" />
              {/* Derived from the ticker tier, never hardcoded. */}
              <span>{pad2(miniCount())} Members</span>
            </Reveal>

            <Reveal className="ml-marquee">
              <div className="ml-row">
                {/* Duplicated once — the keyframe translates -50%, so the second
                    copy scrolls in seamlessly as the first leaves. */}
                <div className="ml-track">
                  {[...ticks, ...ticks].map((m, i) => (
                    <MiniQuote member={m} key={`${m.id}-${i}`} />
                  ))}
                </div>
              </div>
            </Reveal>
          </>
        )}

        {inperson && (
          <Reveal>
            <InPersonQuote member={inperson} />
          </Reveal>
        )}
      </div>
    </section>
  );
}
