"use client";

import Link from "next/link";
import { isRouteVisible } from "@/lib/site-visibility";
import { useCallback, useEffect, useRef, useState } from "react";

interface Panel {
  num: string;
  eyebrow: string;
  title: string;
  emphasis: string;
  desc: string;
  stat: string;
  statPlus?: string;
  statLabel: string;
  watermark: string;
  light?: boolean;
  cta?: { label: string; href: string; external?: boolean };
}

const PANELS: Panel[] = [
  {
    num: "01",
    eyebrow: "Education",
    title: "Web3 Knowledge,",
    emphasis: "For Everyone.",
    desc: "We run daily teaching sessions and open Q&A hosted by our mentors — completely free. Get real answers, live breakdowns, and hands-on guidance every single day.",
    stat: "100",
    statPlus: "+",
    statLabel: "Free Lessons",
    watermark: "Education",
    cta: { label: "Start learning", href: "/learn" },
  },
  {
    num: "02",
    eyebrow: "Mentorship",
    title: "Guided by Experts,",
    emphasis: "Built for You.",
    desc: "Get direct access to experienced traders and Web3 builders. Our mentorship program pairs you with the right mentor so you can grow faster with real feedback.",
    stat: "500",
    statPlus: "+",
    statLabel: "Students Mentored",
    watermark: "Mentorship",
    light: true,
    cta: { label: "Apply for mentorship", href: "/mentorship" },
  },
  {
    num: "03",
    eyebrow: "Tools",
    title: "Powerful Tools,",
    emphasis: "Always Free.",
    desc: "From the BigBoss Calculator to live market updates and airdrop trackers — every tool we build is designed to give you an edge, completely free of charge.",
    stat: "5",
    statPlus: "+",
    statLabel: "Free Tools",
    watermark: "Tools",
    cta: { label: "Explore the tools", href: "/tools" },
  },
];

/**
 * Scroll-driven panel slider. The section is 600vh tall with a sticky 100vh
 * wrap; scroll progress through the section selects the active panel.
 */
export function OfferSlider() {
  const sectionRef = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const section = sectionRef.current;
      if (!section) return;
      const scrolled = Math.max(0, -section.getBoundingClientRect().top);
      const total = section.offsetHeight - window.innerHeight;
      const progress = total > 0 ? Math.min(1, scrolled / total) : 0;
      setActive(Math.min(PANELS.length - 1, Math.floor(progress * PANELS.length)));
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const goTo = useCallback((idx: number) => {
    const section = sectionRef.current;
    if (!section) return;
    const total = section.offsetHeight - window.innerHeight;
    window.scrollTo({
      top: section.offsetTop + (idx / PANELS.length) * total,
      behavior: "smooth",
    });
  }, []);

  return (
    <section id="what-we-offer" className="v2-dark" ref={sectionRef}>
      <div className={`offer-wrap${PANELS[active].light ? " offer-wrap-light" : ""}`}>
        {PANELS.map((panel, i) => (
          <div
            key={panel.num}
            className={`offer-panel${panel.light ? " offer-light" : ""}${
              i === active ? " is-active" : ""
            }`}
            data-panel={i}
          >
            <div className="offer-left">
              <div className="offer-eyebrow">
                <span className="offer-num-label">{panel.num}</span> {panel.eyebrow}
              </div>
              <h2 className="offer-title">
                {panel.title}
                <br />
                <em className="ht-serif">{panel.emphasis}</em>
              </h2>
              <p className="offer-desc">{panel.desc}</p>
              {/* The panel copy stands on its own during soft launch; only the
                  CTA is dropped when its destination is gated. */}
              {panel.cta && isRouteVisible(panel.cta.href) && (
                <Link href={panel.cta.href} className="btn-dark offer-apply-btn">
                  <span>{panel.cta.label}</span>
                  <span className="btn-icon">↗</span>
                </Link>
              )}
            </div>
            <div className="offer-right">
              <div className="offer-big-stat">
                <span className="offer-big-num">{panel.stat}</span>
                {panel.statPlus && <span className="offer-big-plus">{panel.statPlus}</span>}
              </div>
              <div className="offer-big-label">
                <span className="offer-dash-line" /> {panel.statLabel}
              </div>
            </div>
            <div className="offer-watermark">{panel.watermark}</div>
          </div>
        ))}

        <div className="offer-nav-bar">
          {PANELS.map((panel, i) => (
            <button
              key={panel.num}
              className={`offer-nav-dash${i === active ? " is-active" : ""}`}
              data-target={i}
              aria-label={panel.eyebrow}
              aria-current={i === active}
              onClick={() => goTo(i)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
