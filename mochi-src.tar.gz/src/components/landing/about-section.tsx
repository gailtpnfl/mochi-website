"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { TeamGrid } from "@/components/team-grid";
import type { TeamMember } from "@/lib/types";

const DISCORD_URL = process.env.NEXT_PUBLIC_DISCORD_URL || "https://discord.gg/ZGJm8vKUbz";

const TIMELINE = [
  {
    date: "November 2025",
    title: "The Beginning",
    body: "Mochi Web3 was founded with a single belief: Web3 education should be free, accessible, and honest. We started with a small group of traders sharing real knowledge — no hype, no paid gatekeeping.",
  },
  {
    date: "Early 2026",
    title: "Community Growth",
    body: "Word spread fast. Our no-nonsense approach to crypto education attracted thousands of learners — from total beginners to experienced traders looking for a disciplined community.",
  },
  {
    date: "Mid 2026",
    title: "Expanding the Ecosystem",
    body: "We launched curated airdrop guides, live trading sessions, and the BigBoss Calculator — free tools built to give every member a real edge.",
  },
  {
    date: "Now",
    title: "Building the Future",
    body: "NFT collections, community merch, real-time market tools, and mentorship programs — we're building the most complete free Web3 ecosystem for our members.",
  },
];

export function AboutSection({ team }: { team: TeamMember[] }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <section id="story" className="v2-light">
        <div className="about-split">
          <div className="about-img-col">
            {/* PLACEHOLDER: swap for a real community/team photo */}
            <Image
              src="/images/landing/about-community.png"
              alt="The Mochi Web3 community"
              className="about-photo"
              width={900}
              height={1100}
              priority
            />
          </div>
          <div className="about-text-col">
            <div className="about-eyebrow">
              <span className="badge-dot" />
              <span>About Us</span>
            </div>
            <h2>
              A growing community,
              <br />
              <em className="ht-serif">big impact.</em>
            </h2>
            <p>
              Mochi Web3 was founded on a single belief: Web3 education should be free, accessible,
              and honest. What started as a small group of traders became a community built on real
              knowledge — no hype, no gatekeeping.
            </p>
            <p>
              From beginner guides to advanced trading strategies, from curated airdrop hunts to
              live mentorship sessions — everything we do is for the community, by the community.
            </p>
            <button className="btn-dark about-learn-btn" onClick={() => setOpen(true)}>
              <span>Learn more about us</span>
              <span className="btn-icon">↗</span>
            </button>
          </div>
        </div>
      </section>

      <div
        id="about-overlay"
        className={`about-overlay${open ? " is-open" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label="About Mochi Web3"
        aria-hidden={!open}
      >
        <button className="about-overlay-close" onClick={() => setOpen(false)} aria-label="Close">
          ✕
        </button>

        <div className="ao-section ao-dark">
          <div className="ao-container">
            <p className="ao-super">Mochi Web3 · About Us</p>
            <h2 className="ao-section-title">
              Our <em className="ht-serif">Story</em>
            </h2>
            <p className="ao-intro">
              From a small chat group to a Web3 community that learns together — here&apos;s how
              Mochi Web3 came to be.
            </p>
            <div className="ao-timeline">
              {TIMELINE.map((item) => (
                <div className="ao-tl-item" key={item.title}>
                  <div className="ao-tl-dot" />
                  <div className="ao-tl-content">
                    <div className="ao-tl-date">{item.date}</div>
                    <h3>{item.title}</h3>
                    <p>{item.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="ao-section ao-light">
          <div className="ao-container">
            <p className="ao-super ao-super-light">Mochi Web3 · People</p>
            <h2 className="ao-section-title ao-title-dark">
              Meet the <em className="ht-serif">Core Team</em>
            </h2>
            <p className="ao-intro ao-intro-dark">
              The people behind Mochi Web3 — traders, builders, and educators united by one mission.
            </p>
            {/* Same grid as /team, from the same roster — no separate list to
                keep in sync. */}
            <div className="mw-team">
              <TeamGrid members={team} />
            </div>
            <div style={{ marginTop: "2rem", textAlign: "center" }}>
              <Link href="/team" className="card-link">
                Open the full team page →
              </Link>
            </div>
          </div>
        </div>

        <div className="ao-section ao-dark ao-cta-section">
          <div className="ao-container" style={{ textAlign: "center" }}>
            <p className="ao-cta-label">Ready to start your Web3 journey?</p>
            <a href={DISCORD_URL} className="btn-dark" target="_blank" rel="noopener noreferrer">
              <span>Join Our Discord</span>
              <span className="btn-icon">↗</span>
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
